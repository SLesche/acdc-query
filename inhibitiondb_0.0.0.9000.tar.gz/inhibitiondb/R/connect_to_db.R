connect_to_db <- function(path_to_db){
  # TODO: Write this function
  # connects
  # return(conn)
}
